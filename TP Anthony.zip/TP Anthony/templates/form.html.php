<?php

// Formulaires d'exemple

?>

<?php if (isset($_GET['id'])) : ?>
    <form action="update.php" method="post">
        <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
        <label for="title">Nom du livre</label>
        <input type="text" name="title" value="<?= $book['title'] ?>">
        <label for="author">Auteur</label>
        <input type="text" name="author" value="<?= $book['author'] ?>">
        <label for="stock">Stock actuel</label>
        <input type="number" name="number" value="<?= $book['stock'] ?>">
        <input type="submit" value="Modifier">
    </form>
<?php else : ?>
    <form action="create.php" method="post">
        <input type="number" name="isbn" placeholder="ISBN">
        <input type="text" name="title" placeholder="Titre">
        <input type="text" name="author" placeholder="Auteur">
        <input type="number" name="stock" placeholder="Stock">
        <input type="submit" value="Ajouter">
    </form>
<?php endif; ?>

        <form action="" method="POST">
            <label for="nom">ID Book :</label>
            <input type="text" name="nomLivre" value="" required>

            <label for="prenom">ID Client :</label>
            <input type="text" name="nomClient"  value=""required>

            <label for="email">Date de début :</label>
            <input type="text" name="startDate"  value="" required>

            <label for="email">Date de fin :</label>
            <input type="text" name="endDate"  value="" required>

            <input type="submit" value="Réserver">
        </form>
        



<?php  

    $host = 'mysql:dbname=biblioApp;host=localhost';
    $user = 'root';
    $password = '';

    try {
    $pdo = new PDO($host, $user, $password);

    // Si l'ID de l'utilisateur est défini dans l'URL
    if ($_GET['id']) {

        // Récupérer l'ID du livre depuis l'URL et le mettre dans une variable
        $id = $_GET['id'];

        $sql = 'SELECT * FROM rentals WHERE id = :id';
        $query = $pdo->prepare($sql);
        $query->bindParam(':id',$id,PDO::PARAM_INT);
        $query->execute();
       
        
        // Vérifier si le formulaire a été soumis sous forme de requête POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            // Récupérer les données POST du formulaire
            $nomlivre = $_POST['nomLivre'];
            $nomclient = $_POST['nomClient'];
            $startdate = $_POST['startDate'];
            $enddate = $_POST['endDate'];

            $req = "UPDATE rentals SET book_id = :nomLivre, client_id = :nomCLient, startDate = :start_date, endDate = :end_date WHERE id = $id";

            // Associer les valeurs aux paramètres de la requête SQL
            $stmt = $pdo->prepare($req);
            $stmt->bindValue(':nomLivre', $nomlivre, PDO::PARAM_INT);
            $stmt->bindValue(':nomClient', $nomclient, PDO::PARAM_INT);
            $stmt->bindValue(':start_date', $startdate, PDO::PARAM_STR);
            $stmt->bindValue(':end_date', $enddate, PDO::PARAM_STR);
            // Exécuter la requête SQL
            $stmt->execute();

        }
    }
} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}