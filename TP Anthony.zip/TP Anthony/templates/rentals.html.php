<?php
require_once('./classes/Book.php');
$books = Book::getBooks();
require_once('./classes/Rental.php');
$rentals = Rental::getRentals();
require_once('./classes/User.php');
$users = User::getUsers();

?>
<tr class = 'tabrentals'>
<?php foreach ($books as $book) : ?>
    <td class="book__title">
        <?= $book['title'] ?>
    </td>
<?php endforeach; ?>

<?php foreach ($users as $user) : ?>
    <td >
        <?= $user['firstname'];?> <br> <?php echo $user['lastname']; ?>
    </td>
<?php endforeach; ?>

<?php foreach ($rentals as $rental) : ?>
    <td class="book_link">
        <?= $rental['start_date'] ?>
        /
        <?= $rental['end_date'] ?>
    </td>
<?php endforeach; ?>
</tr>
